//
//  RNYAxisChartManagerBridge.h
//  reactNativeCharts
//
//  Created by xudong wu on 26/02/2017.
//  Copyright wuxudong
//

#ifndef RNYAxisChartManagerBridge_h
#define RNYAxisChartManagerBridge_h

#define EXPORT_Y_AXIS_CHART_BASE_PROPERTIES \
EXPORT_CHART_BASE_PROPERTIES \
RCT_EXPORT_VIEW_PROPERTY(yAxis, NSDictionary)


#endif /* RNYAxisChartManagerBridge_h */
