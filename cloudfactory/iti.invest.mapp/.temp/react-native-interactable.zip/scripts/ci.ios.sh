npm install
# npm run podinstall
# npm run build:ios
# npm run e2e:ios
