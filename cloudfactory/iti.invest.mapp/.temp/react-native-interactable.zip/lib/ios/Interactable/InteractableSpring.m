//
//  InteractableSpring.m
//  Interactable
//
//  Created by Tal Kol on 2/9/17.
//  Copyright © 2017 Wix. All rights reserved.
//

#import "InteractableSpring.h"

@implementation InteractableSpring

- (id)copyWithZone:(__unused NSZone *)zone
{
    return self;
}

@end
