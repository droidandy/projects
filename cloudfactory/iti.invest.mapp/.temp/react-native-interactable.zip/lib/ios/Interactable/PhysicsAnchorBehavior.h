//
//  PhysicsAnchorBehavior.h
//  Interactable
//
//  Created by Tal Kol on 2/9/17.
//  Copyright © 2017 Wix. All rights reserved.
//

#import "PhysicsBehavior.h"

@interface PhysicsAnchorBehavior : PhysicsBehavior

@end
