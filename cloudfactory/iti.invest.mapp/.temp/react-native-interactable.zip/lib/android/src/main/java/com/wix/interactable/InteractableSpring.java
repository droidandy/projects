package com.wix.interactable;

/**
 * Created by zachik on 12/02/2017.
 */

public class InteractableSpring {
    float tension;
    float damping;


    public InteractableSpring(float tension, float damping) {
        this.tension = tension;
        this.damping = damping;
    }
}
