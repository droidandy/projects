module.exports = {
  getProjectRoots() {
    return [__dirname, `${__dirname}/playground`];
  }
};