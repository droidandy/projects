import TouchID from './TouchID';

export default TouchID;
