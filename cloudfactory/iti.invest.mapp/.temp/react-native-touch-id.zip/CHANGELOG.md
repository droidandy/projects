<a name="4.4.1"></a>
## 4.4.1 (2019-02-15)
- Some gradle updates

<a name="4.4.0"></a>
## 4.4.0 (2019-02-15)
- Fixes isSupported to allow for a passcodeFallback config option to be passed in
- https://github.com/naoufal/react-native-touch-id/pull/182

<a name="4.3.0"></a>
## 4.3.0 (2018-10-27)
- Change android prop *color* to *imageColor* and add extra properties
- Change android to allow for up to five attempts as platform default
- https://github.com/naoufal/react-native-touch-id/pull/163

<a name="4.2.0"></a>
## 4.2.0 (2018-10-27)
- Adds optional passcodeFallBack option for when device does not have touch or face ID
- https://github.com/naoufal/react-native-touch-id/pull/101

<a name="4.0.1"></a>
## 4.1.0 (2018-09-21)
- Adds optional unifiedErrors config to share errors between platforms
- Adds options to change sensor text + cancel text on Android for localization purposes

<a name="4.0.1"></a>
### 4.0.1 (2018-03-10)

<a name="4.0.0"></a>
## 4.0.0 (2018-01-16)
- Adds Android support
- Adds FaceID detection

