//
//  SecurityV2.h
//  VBNativeAuth
//
//  Created by Dmitry Chudnyy on 11/02/2019.
//  Copyright © 2019 ORGANIZATIONNAME. All rights reserved.
//

#import <React/RCTBridgeModule.h>

@interface SecurityV2 : NSObject<RCTBridgeModule>

@end
