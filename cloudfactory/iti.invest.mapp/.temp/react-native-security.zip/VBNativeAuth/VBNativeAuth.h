//
//  VBNativeAuth.h
//  VBAuth
//
//  Created by Dmitriy Tsurkan on 2/19/18.
//  Copyright © 2018 Dima Tsurkan. All rights reserved.
//

#import <React/RCTBridgeModule.h>

@interface VBNativeAuth : NSObject<RCTBridgeModule>

@end
